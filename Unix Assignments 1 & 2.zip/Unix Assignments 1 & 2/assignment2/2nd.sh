#! /bin/bash 
MYUSERNAME="pravin"
MYPASSWORD="Pravin@123"
STARTOFSCRIPT=`date`
ENDOFSCRIPT=`date`
echo "my login name is: $MYUSERNAME"
echo "my login password is:$MYPASSWORD"
echo  " i start my script at:$STARTOFSCRIPT"
echo " i end my script at: $ENDOFSCRIPT"

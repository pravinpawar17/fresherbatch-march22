#!/bin/bash
MYUSERNAME="pravin"
echo "we r use default user :$MYUSERNAME"
DATETIMESTAMP=`date`
echo "this is when script run:$DATETIMESTAMP"


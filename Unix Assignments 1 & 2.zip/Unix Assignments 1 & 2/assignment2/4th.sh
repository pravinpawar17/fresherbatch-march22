#!/bin/bash
echo "hello shell script"
echo "hello linux">>/dev/null

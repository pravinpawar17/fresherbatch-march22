#!/bin/bash

num1=2
num2=4

echo  $(($num1 + $num2))
echo "Status is $?"

 
 rm  hello.sh


echo $(( 4 - 5 ))

echo "status is $?" 


#! /bin/bash
echo "user name: $USER"
echo "Home Directory is :$HOME"
echo " History file will ignore:$HISTOCONTROL"
echo "Terminal session type is :$TERM"


#!/bin/bash 
value=`cat superhero.txt`
echo "$value"

#!/bin/bash

arr=(mi csk rr lsg)
for i in ${arr[*]}
do
    echo "array values are $i"
done   

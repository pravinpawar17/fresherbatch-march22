#!/bin/bash
echo "enter username"
read username
echo "enter password"
read password
echo "your username is $username and password is $password "
